# EmojiStore
A python package that stores all unicode emojis grouped by category !
